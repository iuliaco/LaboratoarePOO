public interface Strategy {
    float calcul(int aniVechime, float salariu);
}
