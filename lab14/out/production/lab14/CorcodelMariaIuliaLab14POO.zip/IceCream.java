public interface IceCream {
    String getDescription();
    double getCost();

}
