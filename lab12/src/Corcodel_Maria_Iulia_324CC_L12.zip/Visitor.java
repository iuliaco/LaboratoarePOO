public interface Visitor {
    void visit (Director f);
    void visit (Fisier f);
}
